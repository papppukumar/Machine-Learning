Video link: https://www.youtube.com/watch?v=fFwRC-fapIU

Xampp download link: https://www.apachefriends.org/index.html
World dataset : https://www.kaggle.com/busielmorley/worldcities-pop-lang-rank-sql-create-tbls?select=world.sql
Pandas read_json documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_json.html
Pandas read_sql_query documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_sql_query.html#pandas.read_sql_query
